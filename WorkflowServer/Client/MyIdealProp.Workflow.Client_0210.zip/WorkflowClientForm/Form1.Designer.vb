﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDatafields = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnComplete = New System.Windows.Forms.Button()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.btnGetAllWorklist = New System.Windows.Forms.Button()
        Me.cbProcessName = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbUser = New System.Windows.Forms.ComboBox()
        Me.gridWorklist = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.GridColumn1 = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.GridColumn2 = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.GridColumn3 = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.GridColumn4 = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.GridColumn5 = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.GridColumn6 = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.GridColumn7 = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.GridColumn8 = New DevExpress.XtraGrid.Columns.GridColumn()
        CType(Me.gridWorklist, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDatafields
        '
        Me.btnDatafields.Location = New System.Drawing.Point(480, 53)
        Me.btnDatafields.Name = "btnDatafields"
        Me.btnDatafields.Size = New System.Drawing.Size(57, 23)
        Me.btnDatafields.TabIndex = 12
        Me.btnDatafields.Text = "Data Fields"
        Me.btnDatafields.UseVisualStyleBackColor = True
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(417, 53)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(57, 23)
        Me.btnRefresh.TabIndex = 10
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'btnComplete
        '
        Me.btnComplete.Location = New System.Drawing.Point(99, 53)
        Me.btnComplete.Name = "btnComplete"
        Me.btnComplete.Size = New System.Drawing.Size(107, 23)
        Me.btnComplete.TabIndex = 9
        Me.btnComplete.Text = "Complete Task"
        Me.btnComplete.UseVisualStyleBackColor = True
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(182, 24)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(93, 23)
        Me.btnCreate.TabIndex = 7
        Me.btnCreate.Text = "Create Process"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'btnGetAllWorklist
        '
        Me.btnGetAllWorklist.Location = New System.Drawing.Point(12, 53)
        Me.btnGetAllWorklist.Name = "btnGetAllWorklist"
        Me.btnGetAllWorklist.Size = New System.Drawing.Size(81, 23)
        Me.btnGetAllWorklist.TabIndex = 8
        Me.btnGetAllWorklist.Text = "Get Worklist"
        Me.btnGetAllWorklist.UseVisualStyleBackColor = True
        '
        'cbProcessName
        '
        Me.cbProcessName.FormattingEnabled = True
        Me.cbProcessName.Items.AddRange(New Object() {"TestProcess", "TaskProcess", "LeadsSearchRequest"})
        Me.cbProcessName.Location = New System.Drawing.Point(73, 26)
        Me.cbProcessName.Name = "cbProcessName"
        Me.cbProcessName.Size = New System.Drawing.Size(103, 21)
        Me.cbProcessName.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Process:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 4)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Login User:"
        '
        'cbUser
        '
        Me.cbUser.FormattingEnabled = True
        Me.cbUser.Items.AddRange(New Object() {"Chris YAN", "Tester"})
        Me.cbUser.Location = New System.Drawing.Point(73, 1)
        Me.cbUser.Name = "cbUser"
        Me.cbUser.Size = New System.Drawing.Size(103, 21)
        Me.cbUser.TabIndex = 16
        '
        'gridWorklist
        '
        Me.gridWorklist.Cursor = System.Windows.Forms.Cursors.Default
        Me.gridWorklist.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.gridWorklist.Location = New System.Drawing.Point(0, 82)
        Me.gridWorklist.MainView = Me.GridView1
        Me.gridWorklist.Name = "gridWorklist"
        Me.gridWorklist.Size = New System.Drawing.Size(542, 278)
        Me.gridWorklist.TabIndex = 17
        Me.gridWorklist.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.GridColumn1, Me.GridColumn2, Me.GridColumn3, Me.GridColumn4, Me.GridColumn5, Me.GridColumn6, Me.GridColumn7, Me.GridColumn8})
        Me.GridView1.GridControl = Me.gridWorklist
        Me.GridView1.Name = "GridView1"
        '
        'GridColumn1
        '
        Me.GridColumn1.Caption = "Display Name"
        Me.GridColumn1.FieldName = "DisplayName"
        Me.GridColumn1.Name = "GridColumn1"
        Me.GridColumn1.Visible = True
        Me.GridColumn1.VisibleIndex = 0
        '
        'GridColumn2
        '
        Me.GridColumn2.Caption = "Process Name"
        Me.GridColumn2.FieldName = "ProcessName"
        Me.GridColumn2.Name = "GridColumn2"
        Me.GridColumn2.Visible = True
        Me.GridColumn2.VisibleIndex = 1
        '
        'GridColumn3
        '
        Me.GridColumn3.Caption = "Activity Name"
        Me.GridColumn3.FieldName = "ActivityName"
        Me.GridColumn3.Name = "GridColumn3"
        Me.GridColumn3.Visible = True
        Me.GridColumn3.VisibleIndex = 2
        '
        'GridColumn4
        '
        Me.GridColumn4.Caption = "Item Data"
        Me.GridColumn4.FieldName = "ItemData"
        Me.GridColumn4.Name = "GridColumn4"
        Me.GridColumn4.Visible = True
        Me.GridColumn4.VisibleIndex = 3
        '
        'GridColumn5
        '
        Me.GridColumn5.Caption = "Start Date"
        Me.GridColumn5.DisplayFormat.FormatString = "G"
        Me.GridColumn5.FieldName = "StartDate"
        Me.GridColumn5.Name = "GridColumn5"
        Me.GridColumn5.Visible = True
        Me.GridColumn5.VisibleIndex = 4
        '
        'GridColumn6
        '
        Me.GridColumn6.Caption = "Status"
        Me.GridColumn6.FieldName = "Status"
        Me.GridColumn6.Name = "GridColumn6"
        Me.GridColumn6.Visible = True
        Me.GridColumn6.VisibleIndex = 5
        '
        'GridColumn7
        '
        Me.GridColumn7.Caption = "ProcSchemeName"
        Me.GridColumn7.FieldName = "ProcSchemeDisplayName"
        Me.GridColumn7.Name = "GridColumn7"
        Me.GridColumn7.Visible = True
        Me.GridColumn7.VisibleIndex = 6
        '
        'GridColumn8
        '
        Me.GridColumn8.Caption = "Priority"
        Me.GridColumn8.FieldName = "Priority"
        Me.GridColumn8.Name = "GridColumn8"
        Me.GridColumn8.Visible = True
        Me.GridColumn8.VisibleIndex = 7
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(542, 360)
        Me.Controls.Add(Me.gridWorklist)
        Me.Controls.Add(Me.cbUser)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbProcessName)
        Me.Controls.Add(Me.btnDatafields)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.btnComplete)
        Me.Controls.Add(Me.btnCreate)
        Me.Controls.Add(Me.btnGetAllWorklist)
        Me.Name = "FrmMain"
        Me.Text = "Workflow Client"
        CType(Me.gridWorklist, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnDatafields As System.Windows.Forms.Button
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnComplete As System.Windows.Forms.Button
    Friend WithEvents btnCreate As System.Windows.Forms.Button
    Friend WithEvents btnGetAllWorklist As System.Windows.Forms.Button
    Friend WithEvents cbProcessName As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cbUser As System.Windows.Forms.ComboBox
    Friend WithEvents gridWorklist As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GridColumn1 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn2 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn3 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn4 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn5 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn6 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn7 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn8 As DevExpress.XtraGrid.Columns.GridColumn

End Class
